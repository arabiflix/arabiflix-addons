import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.netflix/?site=cFav&function=delBookmarkMenu)", True)

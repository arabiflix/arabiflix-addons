﻿import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.netflix/?site=cGui&function=viewParents)", True)

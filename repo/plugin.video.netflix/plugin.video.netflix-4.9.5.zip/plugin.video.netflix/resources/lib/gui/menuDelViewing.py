import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.netflix/?site=cViewing&function=delViewingMenu)", True)
